package main

import "github.com/Cool-Andrey/Calculating/pkg/internal/application"

func main() {
	app := application.New()
	app.RunServer()
}
